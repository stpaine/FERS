   function xx = chirp(start_freq, end_freq, time, samp_freq, amp)
   %function xx = chirp(start_freq, end_freq, time, samp_freq)
   %
   %	generates a chirp signal that increases linearly from <start_freq> 
   %	to <end_freq> over <time> seconds.
   %	<samp_freq> is the sampling frequency
   %	<amp> is the signal amplitude
   
   end_freq_comp = (end_freq - start_freq)/(2*time);
   
   fsamp = samp_freq; 		% set sampling frequency
   dt =1/fsamp; 			% set sampling interval
   dur = time;			% set signal duration in seconds
   tt=0:dt:dur; 			% create vector of time samples
   psi =2*pi*(100+start_freq*tt+end_freq_comp*tt.*tt);% set argument for chirp function
   xx=amp*cos(psi);		% modulate signal
   
   fprintf('Writing HDF5 data...\n');
   hdf5write('chirp.h5', '/I/value', real(xx), '/Q/value', imag(xx));
   fprintf('Complete.\n');