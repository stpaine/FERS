%Generate a 50 micro second rect pulse, sampled at 100MHz
Fs=1e8;
y=zeros(1, 100);
y(25:75)=1;
%FERS needs pulses to be slightly oversampled, so we take out the top 20% of the band (in a very non-optimal fashion)
Y=fft(y);
Y(40:60)=0;
y=real(ifft(Y));

%Now write to an hdf5 file that fers can read
fprintf('Writing HDF5 data...\n');
hdf5write('.h5', '/I/value', real(y), '/Q/value', imag(y));
fprintf('Complete.\n');