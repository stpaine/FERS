close all;

%% Initial calculations.
c = 299792458;                      % speed of light
sim_length = 10e-3;                 % simultion length [s]
Fs = 10e6;                          % sampling frequency [Hz]
Ns = Fs*sim_length;                 % number of recorded samples
B = 1e6;                            % chirp bandwidth [Hz]
Tm = 100e-6;                        % pulse length [s]
Phi = 0;                            % initial phase [rad]
K = B/Tm;                           % chirp rate [Hz/s]

PRF = 1e3;                          % pulse repetition frequency
PRI = 1/PRF;
pulses = floor(Ns/(Fs*PRI));        % number of pulses
Np = ceil(Fs*Tm);                   % number of samples each pulse will be zero padded to.
Runamb = c*PRI/2;                   % unambiguous range [m]
NFFT = 2^nextpow2(Fs*PRI);

RTI = zeros(NFFT, pulses);

t_pulse = linspace(0, Tm, Tm*Fs);

ref = exp(1i*pi*K*t_pulse.^2 + 1i*Phi);
ref_fft = fft(ref, NFFT);
H = conj(ref_fft);

raw_data = loadfersHDF5('monostatic.h5');

for i = 0 : pulses - 1
  
  pr = (floor(i*Fs*PRI) + 1 : floor((i + 1)*Fs*PRI)); %samples for current PRI 
  pulse = raw_data(pr)';  
  pulse_fft = fft(pulse, NFFT);
  PC = ifft(pulse_fft.*H, NFFT);
  RTI(:, i+1) = abs(PC);
  if (i < 5)
      figure(1);
      plot(abs(PC));
    pause;
  end  
end;

figure(2)
imagesc(RTI);

% fileID = fopen('output.bin','w');
% fwrite(fileID, raw_data, 'uint16');
% fclose(fileID);

