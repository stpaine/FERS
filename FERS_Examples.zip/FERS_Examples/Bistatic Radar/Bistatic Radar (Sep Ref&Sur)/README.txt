Simply run the 'runFERS' script in matlab to simulate and plot a single PRI.

To just run FERS (no plot), simply run the 'runSIM' script. Data will be output as a
.csv file with real data. This can be converted to IQ data by running hdf5 output through
the 'loadfersHDF5' script (as opposed to doing it manually).

To just plot (after obtaining outputs), use the 'plotResults' script.
